﻿namespace BDP.Web.Dtos.Responses;

public record SignInResponse(string AccessToken, string RefreshToken);