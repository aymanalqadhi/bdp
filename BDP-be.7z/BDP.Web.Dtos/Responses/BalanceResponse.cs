﻿namespace BDP.Web.Dtos.Responses;

public record BalanceResponse(decimal Virtual, decimal Usable);