﻿using System.ComponentModel.DataAnnotations;

namespace BDP.Web.Dtos.Requests;

public class DepositRequest
{
    /// <summary>
    /// Gets or sets the amount to deposit
    /// </summary>
    [Required]
    [Range(1, 1_000_000)]
    public decimal Amount { get; set; }
}
