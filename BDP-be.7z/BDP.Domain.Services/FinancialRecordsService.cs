﻿using BDP.Domain.Entities;
using BDP.Domain.Repositories;
using BDP.Domain.Services.Exceptions;
using BDP.Domain.Services.Interfaces;

using System.Linq.Expressions;

namespace BDP.Domain.Services;

public class FinancialRecordsService : IFinancialRecordsService
{
    #region Private fields

    private readonly IUnitOfWork _uow;
    private readonly IAttachmentsService _attachmentsSvc;

    #endregion

    #region Ctors

    /// <summary>
    /// Default constructor
    /// </summary>
    /// <param name="uow">The unit-of-work of the application</param>
    /// <param name="attachmentsSvc">The attachment managment service of the application</param>
    public FinancialRecordsService(IUnitOfWork uow, IAttachmentsService attachmentsSvc)
    {
        _uow = uow;
        _attachmentsSvc = attachmentsSvc;
    }

    #endregion

    #region Public mehtods


    /// <inheritdoc/>
    public IAsyncEnumerable<FinancialRecord> ForUserAsync(
        User user,
        Expression<Func<FinancialRecord, object>>[]? includes = null)
    {
        return _uow.FinancialRecords.FilterAsync(f => f.MadeBy.Id == user.Id, includes: includes);
    }


    /// <inheritdoc/>
    public IAsyncEnumerable<FinancialRecord> ForUserAsync(
        int page,
        int pageSize,
        User user,
        bool descOrder = false,
        Expression<Func<FinancialRecord, object>>[]? includes = null)
    {
        return _uow.FinancialRecords.FilterAsync(
            page, pageSize,
            f => f.MadeBy.Id == user.Id,
            descOrder: descOrder,
            includes: includes);
    }

    /// <inheritdoc/>
    public IAsyncEnumerable<FinancialRecordVerification> ForUserVerifiedAsync(
        User user,
        Expression<Func<FinancialRecordVerification, object>>[]? includes = null)
    {
        return _uow
            .FinancialRecordVerficiations
            .FilterAsync(v => v.FinancialRecord.MadeBy.Id == user.Id, includes: includes);
    }

    /// <inheritdoc/>
    public async Task<decimal> TotalUsableAsync(User user)
    {
        decimal total = 0;

        await foreach(var record in ForUserAsync(user))
        {
            if ((record.Verification?.Outcome == FinancialRecordVerificationOutcome.Accepted)
                || (record.Verification is null && record.Amount < 0))
            {
                total += record.Amount;
            }
        }

        return total;
    }

    /// <inheritdoc/>
    public async Task<FinancialRecordVerification> VerifyAsync(
        FinancialRecord record,
        FinancialRecordVerificationOutcome outcome,
        User verifiedBy,
        IUploadFile? document = null,
        string? notes = null)
    {
        await using var tx = await _uow.BeginTransactionAsync();

        if (await _uow.FinancialRecordVerficiations.AnyAsync(v => v.FinancialRecord.Id == record.Id))
            throw new FinancialRecordAlreadyVerifiedException(record); 

        var verification = new FinancialRecordVerification
        {
            Outcome = outcome,
            FinancialRecord = record,
            VerifiedBy = verifiedBy,
            Document = document is not null ? await _attachmentsSvc.SaveAsync(document) : null,
            Notes = notes,
        };

        _uow.FinancialRecordVerficiations.Add(verification);
        await _uow.CommitAsync(tx);

        return verification;
    }

    #endregion
}
