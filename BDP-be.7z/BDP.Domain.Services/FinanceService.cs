﻿using BDP.Domain.Entities;
using BDP.Domain.Repositories;
using BDP.Domain.Services.Exceptions;
using BDP.Domain.Services.Interfaces;

namespace BDP.Domain.Services;

public class FinanceService : IFinanceService
{
    #region Private fields

    private readonly IUnitOfWork _uow;
    private readonly IConfigurationService _configSvc;
    private readonly IRandomGeneratorService _rngSvc;
    private readonly IFinancialRecordsService _financialRecordsSvc;
    private readonly ITransactionsService _transactionsSvc;

    #endregion

    #region Ctors

    /// <summary>
    /// Default constructor
    /// </summary>
    /// <param name="uow">The unit-of-work of the application</param>
    /// <param name="configSvc">The configuration service of the application</param>
    /// <param name="rngSvc">The random generator service of the application</param>
    /// <param name="attachmentsSvc">The attachments managment service</param>
    /// <param name="financialRecordsSvc">The financial documents service</param>
    /// <param name="transactionsSvc">The transactions service</param>
    public FinanceService(
        IUnitOfWork uow,
        IConfigurationService configSvc,
        IRandomGeneratorService rngSvc,
        IFinancialRecordsService financialRecordsSvc,
        ITransactionsService transactionsSvc)
    {
        _uow = uow;
        _configSvc = configSvc;
        _rngSvc = rngSvc;
        _financialRecordsSvc = financialRecordsSvc;
        _transactionsSvc = transactionsSvc;
    }

    #endregion

    #region Public methods

    /// <inheritdoc/>
    public async Task<decimal> TotalVirtualAsync(User user)
    {
        await using var tx = await _uow.BeginTransactionAsync();
        return await CalculateTotalVirtualAsync(user);
    }

    /// <inheritdoc/>
    public async Task<decimal> TotalUsableAsync(User user)
    {
        await using var tx = await _uow.BeginTransactionAsync();
        return await CalculateTotalUsableAsync(user);
    }

    /// <inheritdoc/>
    public async Task<Transaction> TransferAsync(User from, User to, decimal amount)
    {
        await using var tx = await _uow.BeginTransactionAsync();

        if (await CalculateTotalUsableAsync(from) < amount)
            throw new InsufficientBalanceException(from, amount);

        var transaction = new Transaction
        {
            From = from,
            To = to,
            Amount = amount,
            ConfirmationToken = _rngSvc.RandomString(
                _configSvc.GetInt("Auth:Confirmation:TokenLength", 64), RandomStringKind.AlphaNum)
        };

        _uow.Transactions.Add(transaction);
        await _uow.CommitAsync(tx);

        return transaction;
    }

    /// <inheritdoc/>
    public async Task<FinancialRecord> DepositAsync(User user, decimal amount)
    {
        await using var tx = await _uow.BeginTransactionAsync();

        if (amount <= 0)
            throw new InvalidDepositAmountException(amount);

        return await CreateFinancialRecord(user, amount, tx);
    }

    /// <inheritdoc/>
    public async Task<FinancialRecord> WithdrawAsync(User user, decimal amount)
    {
        await using var tx = await _uow.BeginTransactionAsync();

        if (await CalculateTotalUsableAsync(user) < amount)
            throw new InsufficientBalanceException(user, amount);

        return await CreateFinancialRecord(user, amount, tx);
    }

    #endregion

    #region Private methods

    private async Task<FinancialRecord> CreateFinancialRecord(
        User user, decimal amount, IDatabaseTransaction tx)
    {
        if (amount == 0)
            throw new InvalidDepositAmountException(amount);

        if (amount < 0 && await _uow.FinancialRecords.AnyAsync(
            r => r.MadeBy.Id == user.Id && r.Verification == null && r.Amount < 0))
        {
            throw new PendingRequestExistsException("a withdraw request already exists");
        }
        else if (amount > 0 && await _uow.FinancialRecords.AnyAsync
            (r => r.MadeBy.Id == user.Id && r.Verification == null && r.Amount > 0))
        {
            throw new PendingRequestExistsException("a deposit request already exists");
        }

        var depositRecord = new FinancialRecord
        {
            MadeBy = user,
            Amount = amount,
        };

        _uow.FinancialRecords.Add(depositRecord);
        await _uow.CommitAsync(tx);

        return depositRecord;
    }
    
    /// <inheritdoc/>
    private async Task<decimal> CalculateTotalVirtualAsync(User user)
    {
        var recordsTotal = await _financialRecordsSvc.TotalUsableAsync(user);
        var transactionsIn = await _transactionsSvc.TotalInAsync(user, true);
        var transactionsOut = await _transactionsSvc.TotalOutAsync(user, true);

        return recordsTotal + (transactionsIn - transactionsOut);
    }

    private async Task<decimal> CalculateTotalUsableAsync(User user)
    {
        var recordsTotal = await _financialRecordsSvc.TotalUsableAsync(user);
        var transactionsTotal = await _transactionsSvc.TotalUsableAsync(user);

        return recordsTotal + transactionsTotal;
    }


    #endregion
}
