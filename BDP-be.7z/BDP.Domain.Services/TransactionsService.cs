﻿using BDP.Domain.Entities;
using BDP.Domain.Repositories;
using BDP.Domain.Services.Exceptions;
using BDP.Domain.Services.Interfaces;

using System.Linq.Expressions;

namespace BDP.Domain.Services;

public class TransactionsService : ITransactionsService
{
    #region Private fields

    private readonly IUnitOfWork _uow;

    #endregion

    #region Ctors

    /// <summary>
    /// Default constructor
    /// </summary>
    /// <param name="uow">The unit of work of the application</param>
    public TransactionsService(IUnitOfWork uow)
    {
        _uow = uow;
    }

    #endregion

    #region Public methods

    /// <inheritdoc/>
    public IAsyncEnumerable<Transaction> SentBy(User user,
        Expression<Func<Transaction, object>>[]? includes = null)
    {
        return _uow.Transactions.FilterAsync(t => t.From.Id == user.Id, includes);
    }

    /// <inheritdoc/>
    public IAsyncEnumerable<Transaction> ReceivedBy(User user,
        Expression<Func<Transaction, object>>[]? includes = null)
    {
        return _uow.Transactions.FilterAsync(t => t.To.Id == user.Id, includes);
    }

    /// <inheritdoc/>
    public Task<decimal> TotalInAsync(User user, bool confirmedOnly = false)
        => DoCalculateTotal(user, TransactionDirection.Incoming, confirmedOnly);

    /// <inheritdoc/>
    public Task<decimal> TotalOutAsync(User user, bool confirmedOnly = false)
        => DoCalculateTotal(user, TransactionDirection.Outgoing, confirmedOnly);

    /// <inheritdoc/>
    public async Task<decimal> TotalUsableAsync(User user)
        => await TotalInAsync(user, true) - await TotalOutAsync(user);

    /// <inheritdoc/>
    public async Task<TransactionConfirmation> ConfirmAsync(User sender, string confirmationToken)
    {
        var transaction = await _uow
           .Transactions
           .FirstOrDefaultAsync(t => t.ConfirmationToken == confirmationToken && t.From.Id == sender.Id);

        if (transaction == null)
            throw new NotFoundException($"transaction with token `{confirmationToken}' not found");

        return await DoCreateConfirmation(transaction, TransactionConfirmationOutcome.Confirmed);
    }

    /// <inheritdoc/>
    public async Task<TransactionConfirmation> CancelAsync(User receiver, string confirmationToken)
    {
        var transaction = await _uow
           .Transactions
           .FirstOrDefaultAsync(t => t.ConfirmationToken == confirmationToken && t.To.Id == receiver.Id);

        if (transaction == null)
            throw new NotFoundException($"transaction with token `{confirmationToken}' not found");

        return await DoCreateConfirmation(transaction, TransactionConfirmationOutcome.Confirmed);
    }

    #endregion

    #region Private methods

    private async Task<decimal> DoCalculateTotal(
        User user,
        TransactionDirection direction,
        bool confirmedOnly = false)
    {
        decimal total = 0;

        if (confirmedOnly)
        {
            var includes = new Expression<Func<TransactionConfirmation, object>>[] { c => c.Transaction };
            var confirmations = _uow.TransactionConfirmations.FilterAsync(
                direction == TransactionDirection.Incoming
                        ? (c => c.Transaction.To.Id == user.Id)
                        : (c => c.Transaction.From.Id == user.Id),
                includes: includes
            );

            await foreach (var c in confirmations)
            {
                if (c.Outcome == TransactionConfirmationOutcome.Confirmed)
                    total += c.Transaction.Amount;
            }
        }
        else
        {
            var transactions = _uow.Transactions.FilterAsync(
                direction == TransactionDirection.Incoming
                        ? (c => c.To.Id == user.Id)
                        : (c => c.From.Id == user.Id)
            );

            await foreach (var fr in transactions)
                total += fr.Amount;
        }

        return total;
    }

    private async Task<TransactionConfirmation> DoCreateConfirmation(
        Transaction transaction,
        TransactionConfirmationOutcome outcome)
    {
        await using var tx = await _uow.BeginTransactionAsync();

        var confirmation = await _uow
            .TransactionConfirmations
            .FirstOrDefaultAsync(c => c.Transaction.Id == transaction.Id);

        if (confirmation != null)
            throw new TransactionAlreadyConfirmedException(confirmation);

        confirmation = new TransactionConfirmation
        {
            Transaction = transaction,
            Outcome = outcome,
        };

        _uow.TransactionConfirmations.Add(confirmation);
        await _uow.CommitAsync(tx);

        return confirmation;
    }

    #endregion

    private enum TransactionDirection
    {
        Incoming,
        Outgoing,
    }
}