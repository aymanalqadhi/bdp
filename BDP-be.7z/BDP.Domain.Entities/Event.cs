﻿namespace BDP.Domain.Entities;

public class Event : AuditableEntity
{
    /// <summary>
    /// Gets or sets the event title
    /// </summary>
    public string Title { get; set; } = null!;

    /// <summary>
    /// Gets or sets the event description
    /// </summary>
    public string Description { get; set; } = null!;

    /// <summary>
    /// Gets or sets the date/time at which the event takes place
    /// </summary>
    public DateTime TakesPlaceAt { get; set; }

    /// <summary>
    /// Gets or sets the collection of pictures of this event
    /// </summary>
    public ICollection<Attachment> Pictures { get; set; } = new List<Attachment>();

    /// <summary>
    /// Gets or sets the collection of orders associated with this event
    /// </summary>
    public ICollection<ProductOrder> Orders { get; set; } = new List<ProductOrder>();

    /// <summary>
    /// Gets or sets the collection of reservations associated with this event
    /// </summary>
    public ICollection<ServiceReservation> Reservations { get; set; } = new List<ServiceReservation>();

    /// <summary>
    /// Gets or sets the type of the event
    /// </summary>
    public EventType Type { get; set; } = null!;
}
