﻿namespace BDP.Domain.Entities;

public sealed class ProductOrder : AuditableEntity
{
    /// <summary>
    /// Gets or sets the ordered quantity
    /// </summary>
    public uint Quantity { get; set; }

    /// <summary>
    /// Gets or sets the ordered product
    /// </summary>
    public Product Product { get; set; } = null!;

    /// <summary>
    /// Gets or sets the transaction associated with this order
    /// </summary>
    public Transaction Transaction { get; set; } = null!;

    /// <summary>
    /// Gets or sets the status of the order (for caching)
    /// </summary>
    public ProductOrderStatus Status { get; set; } = ProductOrderStatus.Pending;
}

public enum ProductOrderStatus
{
    Pending,
    Canceled,
    Completed,
}