﻿namespace BDP.Domain.Entities;

public sealed class ServiceReservation : AuditableEntity
{
    /// <summary>
    /// Gets or sets the reserved service
    /// </summary>
    public Service Service { get; set; } = null!;

    /// <summary>
    /// Gets or sets the transaction associated with this reservation
    /// </summary>
    public Transaction Transaction { get; set; } = null!;

    /// <summary>
    /// Gets or sets the status of the reservation (for caching)
    /// </summary>
    public ServiceReservationStatus Status { get; set; } = ServiceReservationStatus.Pending;
}

public enum ServiceReservationStatus
{
    Pending,
    Canceled,
    Completed,
}