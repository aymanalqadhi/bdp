﻿using BDP.Domain.Entities;
using BDP.Domain.Services.Interfaces;
using BDP.Web.Dtos;

using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

using System.Linq;

namespace BDP.Web.Api.Controllers;

[Route("api/[controller]")]
[ApiController]
public class SellablesController : ControllerBase
{
    #region Private fileds

    private readonly int _pageSize;

    private readonly IConfigurationService _configurationSvc;
    private readonly IUsersService _usersSvc;
    private readonly ISellablesService _sellablesSvc;
    private readonly IMapper _mapper;

    #endregion

    #region Ctors

    public SellablesController(
        IConfigurationService configurationSvc,
        IUsersService usersSvc,
        ISellablesService sellablesSvc,
        IMapper mapper)
    {
        _configurationSvc = configurationSvc;
        _sellablesSvc = sellablesSvc;
        _usersSvc = usersSvc;
        _mapper = mapper;

        _pageSize = _configurationSvc.GetInt("QuerySettings:DefaultPageSize");
    }

    #endregion

    #region Actions


    [HttpGet("page/{page}")]
    public async Task<IActionResult> GetByUserPaged(string username, int page)
    {
        var user = await _usersSvc.GetByUsernameAsync(username);
        var ret = await _sellablesSvc.GetForAsync(user, page, _pageSize).ToListAsync();

        return Ok(ret.Select((s) => _mapper.Map(s, s.GetType(), typeof(SellableDto))));
    }

    [HttpGet("search")]
    public async Task<IActionResult> Search(string query, int page, string? username)
    {
        var ret = username != null
            ? await _sellablesSvc.SearchForAsync(
                 await _usersSvc.GetByUsernameAsync(username),
                 query,
                 page,
                 _pageSize).ToListAsync()
            : await _sellablesSvc.SearchAsync(query, page, _pageSize).ToListAsync();

        return Ok(ret.Select((s) => _mapper.Map(s, s.GetType(), typeof(SellableDto))));
    }

    #endregion
}
