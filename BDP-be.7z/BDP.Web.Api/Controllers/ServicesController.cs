﻿using BDP.Domain.Services.Interfaces;
using BDP.Web.Api.Auth.Attributes;
using BDP.Web.Api.Extensions;
using BDP.Web.Dtos;
using BDP.Web.Dtos.Requests;

using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BDP.Web.Api.Controllers;

[Route("api/[controller]")]
[ApiController]
public class ServicesController : ControllerBase
{
    #region Private fileds

    private readonly IConfigurationService _configurationSvc;
    private readonly IUsersService _usersSvc;
    private readonly IServicesService _servicesService;
    private readonly IMapper _mapper;

    #endregion

    #region Ctors

    public ServicesController(
        IConfigurationService configurationSvc,
        IUsersService usersSvc,
        IServicesService productsSvc,
        IMapper mapper)
    {
        _configurationSvc = configurationSvc;
        _servicesService = productsSvc;
        _usersSvc = usersSvc;
        _mapper = mapper;
    }

    #endregion

    #region Actions

    [HttpGet("{id}")]
    public async Task<IActionResult> GetById(int id)
        => Ok(_mapper.Map<ServiceDto>(await _servicesService.GetByIdAsync(id)));

    [HttpPost]
    [IsProvider]
    public async Task<IActionResult> Create([FromForm] CreateServiceRequest form)
    {
        var user = await _usersSvc.GetByUsernameAsync(User.GetUsername())!;
        var product = await _servicesService.ListAsync(
            user, form.Title,
            form.Description,
            form.Price,
            form.AvailableBegin,
            form.AvailableEnd,
            form.Attachments?.Select(a => new WebUploadFile(a))
        );

        return CreatedAtAction(
            nameof(GetById),
            new { id = product.Id }, _mapper.Map<ServiceDto>(product)
        );
    }

    [HttpPatch("{id}")]
    [IsProvider]
    public async Task<IActionResult> Update([FromBody] UpdateServiceRequest form, int id)
    {
        await _servicesService.UpdateAsync(
            id,
            form.Title,
            form.Description,
            form.Price,
            form.AvailableBegin,
            form.AvailableEnd);

        return Ok();
    }

    [HttpDelete("{id}")]
    [IsProvider]
    public async Task<IActionResult> Delete(int id)
    {
        var product = await _servicesService.GetByIdAsync(id);

        await _servicesService.UnlistAsync(product);
        return Ok();
    }

    #endregion
}
