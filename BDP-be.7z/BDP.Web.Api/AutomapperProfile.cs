﻿using AutoMapper;

using BDP.Domain.Entities;
using BDP.Domain.Services.Interfaces;
using BDP.Web.Dtos;

namespace BDP.Web.Api;

/// <summary>
/// A profile class for Automapper
/// </summary>
public class AutomapperProfile : Profile
{
    /// <summary>
    /// Default constructor where types mapping occures
    /// </summary>
    public AutomapperProfile()
    {
        // users
        CreateMap<User, UserDto>()
            .ForMember(
                u => u.ProfilePictureUrl,
                o => o.MapFrom(s => s.ProfilePicture != null ? s.ProfilePicture.FullPath : null)
             )
            .ForMember(
                u => u.Groups,
                o => o.MapFrom(s => s.Groups.Select(g => g.Name))
            )
            .ForMember(
                u => u.PhoneNumbers,
                o => o.MapFrom(s => s.PhoneNumbers.Select(p => p.Number))
            );

        // sellables
        CreateMap<Sellable, SellableDto>()
            .ForMember(
                p => p.Attachments,
                o => o.MapFrom(s => s.Attachments.Select(a => a.FullPath))
            )
            .Include<Product, ProductDto>()
            .Include<Service, ServiceDto>();
        CreateMap<Product, ProductDto>();
        CreateMap<Service, ServiceDto>();

        // finacial records
        CreateMap<FinancialRecord, FinancialRecordDto>();
        CreateMap<FinancialRecordVerification, FinancialRecordVerificationDto>()
            .ForMember(
                v => v.IsAccepted,
                o => o.MapFrom(v => v.Outcome == FinancialRecordVerificationOutcome.Accepted)
            );
    }
}
