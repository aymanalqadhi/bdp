﻿namespace BDP.Web.Api.Auth.Jwt;

public static class CustomClaims
{
    public const string Id = "id";
}
