﻿namespace BDP.Web.Api.Auth;

public static class Policies
{
    public const string IsCustomer = "IsCustomer";
    public const string IsProvider = "IsProvider";
    public const string IsRoot = "IsRoot";
}
